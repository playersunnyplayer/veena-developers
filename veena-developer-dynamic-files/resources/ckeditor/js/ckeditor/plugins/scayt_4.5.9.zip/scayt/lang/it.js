﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'it', {
	btn_about: 'About COMS',
	btn_dictionaries: 'Dizionari',
	btn_disable: 'Disabilita COMS',
	btn_enable: 'Abilita COMS',
	btn_langs:'Lingue',
	btn_options: 'Opzioni',
	text_title: 'Controllo Ortografico Mentre Scrivi'
});