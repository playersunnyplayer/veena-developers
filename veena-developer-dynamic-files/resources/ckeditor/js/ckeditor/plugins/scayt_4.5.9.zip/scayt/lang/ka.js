﻿/*
Copyright (c) 2003-2015, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.html or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'scayt', 'ka', {
	btn_about: 'SCAYT-ის შესახებ',
	btn_dictionaries: 'ლექსიკონები',
	btn_disable: 'SCAYT-ის გამორთვა',
	btn_enable: 'SCAYT-ის ჩართვა',
	btn_langs:'ენები',
	btn_options: 'პარამეტრები',
	text_title:  'მართლწერის შემოწმება კრეფისას'
});
