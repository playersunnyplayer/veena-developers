<!DOCTYPE html>
<html lang="en">

<head>
	<title>Veena Developer Palghar - Mhada  लॉटरी     2020</title>
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" charset=utf-8 />

	<link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
	<link rel="stylesheet" type="text/css" href="css/font-awesome.min.css">
	<link rel="stylesheet" type="text/css" href="css/normalize.css">
	<link rel="stylesheet" type="text/css" href="css/reset.css">
	<link rel="stylesheet" href="css/style.css">
	
	<style>
	 .error1 {color: #FF0000;}
	    .validate{
	        border:1px solid red !important;
	    }
	    .error{
	        background:red;
            color:white;
            padding: 3px 4px;
            font-size: 11px;
	    }
	</style>
</head>

<body class="hindiFont">
	<header>
		<div class="topHeader">
			<ul class="container">
				<li><i class="fa fa-language"></i></li>
				<li><a href="hindi.php" class="active">Hindi</a></li>
				<li><a href="index.php">English</a></li>
				<li><a href="marathi.php">Marathi</a></li>
			</ul>
		</div>

		<div class="headerContainer">
			<div class="container">
				<div class="row">
					<figure class="mahada-logo col-xs-4">
						<img src="images/mahada-logo.jpg" alt="">
					</figure>
					<!--<figure class="veena-samrajya-logo col-xs-4">-->
					<!--	<img src="images/veena-samrajya-logo.png" alt="">-->
					<!--</figure>-->
					<figure class="ps-logo col-xs-4">
						<img src="images/ps-logo.png" alt="">
					</figure>
				</div>
			</div>
		</div>
	</header>

	<section class="pageWrap">
		<div class="container">
			<ul class="bulletPoints">
				<li>पालघर(पश्चिम)  में 1 RK और 1 BHK</li>
				<li>PMAY के तहत &nbsp;<i class="fa fa-rupee"></i> 2.5 लाख की सब्सिडी</li>
				<li>MHADA लॉटरी  योजना</li>
				<!--<li>RERA NO P99000021726</li>-->
			</ul>

			<section class="mainForm">
				<h2>क्या आपकी रुचि है !!</h2>
				<form action="sendmail.php" class="d-form" method="post">
					<div class="form-group">
						<label for="name">नाम:</label><span class = "error1"> *</span>
						<input type="text" class="form-control" id="name" placeholder="अपना नाम डालें" name="name">
					</div>
					<div class="form-group">
						<label for="mobile">मोबाइल नंबर:</label><span class = "error1"> *</span>
						<input type="text" class="form-control" id="mobile" placeholder="अपना मोबाइल नंबर डालें"
							name="mobile">
					</div>
					<!--<div class="form-group">-->
					<!--	<label for="email">ईमेल:</label>-->
					<!--	<input type="text" class="form-control" id="email" placeholder="अपना ईमेल डालें" name="email">-->
					<!--</div>-->
					<div class="form-group">
						<label for="Intrested">रुचि है:</label>
						<div class="radio">
							<label>
								<input type="radio" name="optradio" value="1RK" checked>
								1 RK
							</label>
							
							<label>
								<input type="radio" value="1BHK"  name="optradio">
								1 BHK
							</label>
							
							<label>
								<input type="radio" value="Not Interested"  name="optradio">
								Not Interested
							</label>
						</div>
					</div>

					<button type="submit" name="submit" class="btn btn-default">अपना फ़ॉर्म भरें</button>
				</form>
			</section>
		</div>
	</section>

	<footer>
		<a href="tel:1800 120 8040" class="dialBtn">डायल करें <span>@ 1800 120 8040</span></a>
		
		<div class="disclaimer">Disclaimer: Veena Samrajya is registered under <img class="mahareraLogoSmall" src="images/mahada-logo-small.jpg" /> MahaRERA Registration No: P99000021726 | Available at website: <a href="http://maharera.mahaonline.gov.in">http://maharera.mahaonline.gov.in</a> | Project is under Public Private Partnership Model between Veena Developers & MHADA</div>
	</footer>

	<script src="js/jquery.js"></script>
	<script src="js/bootstrap.min.js"></script>
</body>

</html>

<script>
    $(document).ready(function(){
        $(".d-form").submit(function(e){
            
            var mobile = $("input[name='mobile']");
            var email = $("input[name='email']");
            var name = $("input[name='name']");
            
            var mob_v = /^[1-9]{1}[0-9]{9}$/;
            var reg = /^([A-Za-z0-9_\-\.])+\@([A-Za-z0-9_\-\.])+\.([A-Za-z]{2,4})$/;
            
            $("input").removeClass('validate');
            $(".error").remove();
            var error = true;
            if(mobile.val() == ""){
                error = false;
                mobile.addClass('validate');
                mobile.parent().append('<span class="error">Mobile Required</span>');
            }else if(mob_v.test(mobile.val()) == false){
                error = false;
                mobile.addClass('validate');
                mobile.parent().append('<span class="error">Mobile must be number & 10 digit</span>');
            }
            if(name.val() == ""){
                error = false;
                name.addClass('validate');
                name.parent().append('<span class="error">Name Required</span>');
            }
            // if(email.val() == ""){
            //     error = false;
            //     email.addClass('validate');
            //     email.parent().append('<span class="error">Email Required</span>');
            // }else if(reg.test(email.val()) == false){
            //     error = false;
            //     email.addClass('validate');
            //     email.parent().append('<span class="error">Check Email</span>');
            // }
            
            if(!error){
                e.preventDefault();
            }
            
        });
    });
</script>